<!DOCTYPE html>
<html lang="en">
<head>
    <title>Error</title>
</head>
<body>
    <h2>Oops! Something went wrong.</h2>
    <p>The page you're looking for doesn't exist or an error occurred.</p>
    <p><a href="index.php">Return to Home</a></p>
</body>
</html>
