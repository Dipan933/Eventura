-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2024 at 07:34 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eventura`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(125, '29401222050', 'sougatamukherjee504@gmail.com', '$2y$10$tkxpYLB0zM0EI5LZFfKZcukJUIYJA.m2gmMPE.dFz4itC7WS2bbQa', '2024-11-16 18:24:50');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `booking_date` datetime DEFAULT current_timestamp(),
  `status` enum('pending','confirmed','cancelled') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `event_id`, `booking_date`, `status`) VALUES
(1, 5, 3, '2024-11-18 01:40:34', 'confirmed'),
(2, 5, 6, '2024-11-18 01:49:10', 'pending'),
(3, 5, 3, '2024-11-20 10:46:04', 'pending'),
(4, 7, 3, '2024-11-20 11:15:40', 'pending'),
(5, 7, 6, '2024-11-20 11:37:47', 'pending'),
(6, 9, 6, '2024-11-20 13:14:39', 'pending'),
(7, 9, 7, '2024-11-20 15:23:09', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `status` enum('Upcoming','Ongoing','Completed') NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `event_images` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `name`, `event_date`, `status`, `description`, `created_at`, `event_images`) VALUES
(3, 'My Birthday', '2025-01-23', 'Ongoing', '\"Celebrate Sougata\'s Birthday in Style!\"\r\n\r\nJoin us for an unforgettable evening filled with joy, laughter, and cherished memories as we celebrate my special day. Expect:\r\n\r\nDelicious Food & Drinks: A variety of mouthwatering dishes and refreshing beverages to suit every taste.\r\nEntertainment: Live music, games, and surprises to keep the party vibe alive!\r\nTheme: Glam & Glow – Dress to impress!\r\nPhoto Booth Fun: Capture the moments with your friends and family.\r\n📅 Date: 23/01/2025\r\n⏰ Time: Evening\r\n📍 Location: Sonarpur\r\n\r\nBring your smiles and good vibes. Let’s make this birthday celebration one for the books! 🎉', '2024-11-17 18:19:42', 'a:3:{i:0;s:20:\"1732082287_dummy.png\";i:1;s:20:\"1732082287_dummy.png\";i:2;s:20:\"1732082287_dummy.png\";}'),
(6, 'Corporate Anniversary Celebration', '2024-12-12', 'Upcoming', '\"Join us for the grand celebration of our company\'s 10th Anniversary! A day filled with exciting activities, inspiring speeches, and delightful entertainment awaits. Reconnect with colleagues, build new connections, and celebrate a decade of excellence and innovation.\"\r\n\r\nEvent Details\r\nTime: 5:00 PM - 10:00 PM\r\nVenue: Grand Orchid Hall, Downtown City Center\r\nDress Code: Formal\r\nHighlights\r\nKeynote Speech by the CEO\r\nMusical Performance by Live Band\r\nGourmet Dinner and Cocktail Hour\r\nAwards Ceremony for Top Performers', '2024-11-17 19:30:56', 'a:4:{i:0;s:20:\"1732082740_dummy.png\";i:1;s:20:\"1732082740_dummy.png\";i:2;s:20:\"1732082740_dummy.png\";i:3;s:20:\"1732082740_dummy.png\";}'),
(7, 'College Fest', '2024-11-30', 'Upcoming', 'ABCD', '2024-11-20 09:51:32', 'a:2:{i:0;s:20:\"1732096292_dummy.png\";i:1;s:20:\"1732096292_dummy.png\";}');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `gender` enum('male','female','other') NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `name`, `gender`, `profile_image`, `created_at`) VALUES
(7, 'Sou2004', 'sougatamukherjee504@gmail.com', '$2y$10$nhtlfjZ7lCHdhHZRh9BqsujlXFLFaj4t0MXBXoWQp8gJbkHu34YVe', 'Sougata Mukherjee', 'male', 'IMG_20240123_101131.jpg', '2024-11-20 05:41:48'),
(8, 'jnroy', 'test@gmail.com', '$2y$10$eYg6H1odKFSbqRSn0H9MtuQNQjhiWAnp8sdwl.8NsX.1DvTU2vTMG', 'JN Roy', 'male', 'banner.jpg', '2024-11-20 05:44:58'),
(9, 'dipanbanerjee', 'dipan624@gmail.com', '$2y$10$pV6t0xzzS/3syzTwd98DK.F6iGHRoVkgsPeQlmY5OqDxIrr6gY8sO', 'Sougata Mukherjee', 'female', 'founder.jpg', '2024-11-20 07:41:11'),
(10, 'Aishani123', 'aishanimanik9@gmail.com', '$2y$10$vV196K7pBZlob7NbVthWKe6k7u5cTVbu3o2wAQC2.FbI.Lq6mFf0.', 'Aishani Manik', 'female', 'founder.jpg', '2024-11-20 09:55:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
